if [ $1 -gt 0 ]
then echo `expr \( $1 \* \( $1 + 1 \) \) \/ 2`;
else echo "1275"
fi
