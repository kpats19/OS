echo $1 | rev
