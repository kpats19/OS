ls -S | head -n 1
