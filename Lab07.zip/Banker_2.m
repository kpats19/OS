% Author : Hemil Modi(121016) Kavan Patel(121023) Keyur PAtel(121025)
% Date   : 13-03-2015

cMatrix = xlsread('claim.xlsx');
aMatrix = xlsread('allocate.xlsx');
aVector = xlsread('avail.xlsx');



bankers(cMatrix,aMatrix,aVector)

