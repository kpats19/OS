#7. Write a shell script, which takes a filename as command line argument, asks the user
#if he wants to revoke the read, write permissions for the group and others for that
#particular file. If the answer is “y” then it should do so or else it should abort the
#operation.

echo "enter the desired files path"
read f
echo "Do you want to change permissions for this file, enter capital 'Y' to continue?"
read s

if [ $s = Y ];then
echo "enter desired permissions number choice e.g. 754"
read m
sudo chmod $m $f
echo "Thank you permissions changed"
fi

