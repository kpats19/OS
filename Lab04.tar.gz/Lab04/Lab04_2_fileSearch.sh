#2.Write a shell script to check whether the scanned string is 
#found in a file or not.
#Display appropriate message.

read a;
b= grep $a keyur.txt;

if [ $? -eq 0 ]
then              
echo character found ;
else 
echo "character isn't found "
fi

